package com.sa.safetynet.accesscontroller.autodoorsystem;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class AutomatedDoorActivator implements BundleActivator {

	ServiceRegistration autoDoorSystemRegistration;

	public void start(BundleContext context) throws Exception {
		System.out.println("Initiating Automated Door System...");
		AutomatedDoorService autoDoorService = new AutomatedDoorServiceImpl();
		autoDoorSystemRegistration = context.registerService(AutomatedDoorService.class.getName(), autoDoorService, null);
		//detectionService.createEmpTable();
		System.out.println("Automated Door System Initiated!!!");
	}

	public void stop(BundleContext context) throws Exception {
		System.out.println("Aborting Automated Door System...");
		autoDoorSystemRegistration.unregister();
		System.out.println("Automated Door System Aborted!!!");
	}
}
