package com.sa.safetynet.accesscontroller.autodoorsystem;

import java.util.Timer;
import java.util.TimerTask;

public class AutomatedDoorServiceImpl implements AutomatedDoorService{

	@Override
	public void doorUnlock(String location) {
		boolean emergency = false;
		
	    System.out.println("Door Unlocked at " + location);
	    
	    if(emergency == true) {
	    	System.out.println("Emergency situation detected. Unlocking doors immediately.");
	    }
		
	}
	
	@Override
	public void doorLock(String location) {
		
		// Create a Timer object
        Timer timer = new Timer();

        // Schedule a task to run after 30 seconds
        timer.schedule(new TimerTask() {
        	
            @Override
            public void run() {
                System.out.println("Door unlokecked at " + location);
            }
        }, 5 * 1000);
        
		
	}



}
